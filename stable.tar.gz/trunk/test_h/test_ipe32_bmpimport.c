#include "../ipe32_bmpimport.h"

int main(int argc, char *argv[]) {
}

