#include "../ipe_artfile_packer_ipe16_pip.h"

int main(int argc, char *argv[]) {
}

