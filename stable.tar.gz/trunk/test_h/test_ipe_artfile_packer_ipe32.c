#include "../ipe_artfile_packer_ipe32.h"

int main(int argc, char *argv[]) {
}

