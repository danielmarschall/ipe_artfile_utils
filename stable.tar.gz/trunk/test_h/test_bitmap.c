#include "../bitmap.h"

int main(int argc, char *argv[]) {
}

