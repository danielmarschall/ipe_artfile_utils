#include "../ipe16_lzw_encoder.h"

int main(int argc, char *argv[]) {
}

