#include "../ipe16_lzw_decoder.h"

int main(int argc, char *argv[]) {
}

