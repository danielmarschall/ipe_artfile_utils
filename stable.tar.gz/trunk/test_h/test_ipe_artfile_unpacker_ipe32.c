#include "../ipe_artfile_unpacker_ipe32.h"

int main(int argc, char *argv[]) {
}

