#include "../ipe32_artfile.h"

int main(int argc, char *argv[]) {
}

