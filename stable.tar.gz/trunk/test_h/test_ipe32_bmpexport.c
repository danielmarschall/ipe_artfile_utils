#include "../ipe32_bmpexport.h"

int main(int argc, char *argv[]) {
}

